package com.reference.order.listener;

import java.util.Arrays;
import java.util.Optional;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.reference.commitment.dto.OrderAssociationDTO;
import com.reference.order.dto.OrderDTO;

@Component
public class HystrixCallBack {


	  @HystrixCommand(fallbackMethod = "callFallbackAssociateOrder")
	  public OrderAssociationDTO associateOrder(final OrderDTO orderDTO) {
		  RestTemplate template= new RestTemplate();
			final HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			final HttpEntity<OrderDTO> httpEntity = new HttpEntity<>(orderDTO, headers);
			final ResponseEntity<OrderAssociationDTO> response = template.exchange(
					"http://localhost:8082" + "/commitment/associateOrder", HttpMethod.POST, httpEntity,
					new ParameterizedTypeReference<OrderAssociationDTO>() {
					});

			return getResponseBody(response);
		}
	  	
	  @SuppressWarnings("unused")
	  public OrderAssociationDTO callFallbackAssociateOrder(OrderDTO orderDTO) {

	      System.out.println("Commitment Service is down!!! fallback route enabled...");

	      return null ;
	  }
		public static <T> T getResponseBody(ResponseEntity<T> object) {
			T responseBody = null;
			if (Optional.ofNullable(object).isPresent()) {
				responseBody = object.getBody();
			}
			return responseBody;
		}
	  
}
