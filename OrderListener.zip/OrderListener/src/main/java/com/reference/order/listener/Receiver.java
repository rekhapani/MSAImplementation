package com.reference.order.listener;

import java.util.Arrays;
import java.util.Optional;
import java.util.concurrent.CountDownLatch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
//import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.reference.commitment.dto.CommitmentDTO;
import com.reference.commitment.dto.OrderAssociationDTO;
import com.reference.order.dto.OrderDTO;


import lombok.extern.slf4j.Slf4j;
@Slf4j
//@Service
@Component
public class Receiver {
	//public final CommitmentClientService commitmentClient;

  private static final Logger LOGGER =
      LoggerFactory.getLogger(Receiver.class);

  private CountDownLatch latch = new CountDownLatch(1);
  
  @Autowired
  public HystrixCallBack hystrixCallBack;
 
  public CountDownLatch getLatch() {
    return latch;
  }

  
  /*@KafkaListener(topics = "${topic.helloworld}")
  public void receive(Order1DTO payLoad) {
	  
    LOGGER.info("received payload='{}'", payLoad);
    
    latch.countDown();
  }*/
  @KafkaListener(topics = "${topic.helloworld}")
  public void receive(@Payload OrderDTO data,
          @Headers MessageHeaders headers) {
	  
    
    LOGGER.info("received payload='{}'", data.getOrderId());
    System.out.println("Test REceiver" + data);
    OrderAssociationDTO associationDTO =  hystrixCallBack.associateOrder(data);
    System.out.println("Test REceiver associationDTO" + associationDTO);
    latch.countDown();
  }
 
}