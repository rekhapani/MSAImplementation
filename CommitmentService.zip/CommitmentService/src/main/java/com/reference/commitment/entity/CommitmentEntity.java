package com.reference.commitment.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "commitments")
public class CommitmentEntity {

	@Id
	@Column(name = "CommitmentId", nullable = true)
	
	@ApiModelProperty(notes = "The database generated commitment ID")
	private Integer commitmentId;

	@Column(name = "CorporateAccountId")
	@ApiModelProperty(notes = "The National Account ID")
	private Integer corporateAccountId;

	@Column(name = "LineofBusineeId")
	@ApiModelProperty(notes = "The Line of Business ID")
	private Integer lineofBusineeId;

	@Column(name = "BusinessUnit")
	@ApiModelProperty(notes = "The Business unit")
	private String businessUnit;

	@Column(name = "ServiceOffering")
	@ApiModelProperty(notes = "The service Offering")
	private String serviceOffering;

	@Column(name = "OriginArea")
	@ApiModelProperty(notes = "The origin area of the Logistics")
	private String originArea;

	@Column(name = "DestinationArea")
	@ApiModelProperty(notes = "The destination area of the Logistics")
	private String destinationArea;

	@Column(name = "ScheduleFrom")
	@ApiModelProperty(notes = "The schedule start date")
	private Date scheduleFrom;

	@Column(name = "ScheduleTo")
	@ApiModelProperty(notes = "The schedule end Date")
	private Date scheduleTo;

	public Integer getCommitmentId() {
		return commitmentId;
	}

	public void setCommitmentId(Integer commitmentId) {
		this.commitmentId = commitmentId;
	}

	public Integer getCorporateAccountId() {
		return corporateAccountId;
	}

	public void setCorporateAccountId(Integer corporateAccountId) {
		this.corporateAccountId = corporateAccountId;
	}

	public Integer getLineofBusineeId() {
		return lineofBusineeId;
	}

	public void setLineofBusineeId(Integer lineofBusineeId) {
		this.lineofBusineeId = lineofBusineeId;
	}

	public String getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

	public String getServiceOffering() {
		return serviceOffering;
	}

	public void setServiceOffering(String serviceOffering) {
		this.serviceOffering = serviceOffering;
	}

	public String getOriginArea() {
		return originArea;
	}

	public void setOriginArea(String originArea) {
		this.originArea = originArea;
	}

	public String getDestinationArea() {
		return destinationArea;
	}

	public void setDestinationArea(String destinationArea) {
		this.destinationArea = destinationArea;
	}

	public Date getScheduleFrom() {
		return scheduleFrom;
	}

	public void setScheduleFrom(Date scheduleFrom) {
		this.scheduleFrom = scheduleFrom;
	}

	public Date getScheduleTo() {
		return scheduleTo;
	}

	public void setScheduleTo(Date scheduleTo) {
		this.scheduleTo = scheduleTo;
	}
}
