package com.reference.commitment.dto;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.Date;

import lombok.Data;

@Data
public class CommitmentDTO {
	private Integer commitmentId;

	private Integer corporateAccountId;
	private Integer lineofBusineeId;

	private String businessUnit;

	private String serviceOffering;

	private String originArea;

	private String destinationArea;

	private Date scheduleFrom;

	private Date scheduleTo;

	public Integer getCommitmentId() {
		return commitmentId;
	}

	public void setCommitmentId(Integer commitmentId) {
		this.commitmentId = commitmentId;
	}

	public Integer getCorporateAccountId() {
		return corporateAccountId;
	}

	public void setCorporateAccountId(Integer corporateAccountId) {
		this.corporateAccountId = corporateAccountId;
	}

	public Integer getLineofBusineeId() {
		return lineofBusineeId;
	}

	public void setLineofBusineeId(Integer lineofBusineeId) {
		this.lineofBusineeId = lineofBusineeId;
	}

	public String getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

	public String getServiceOffering() {
		return serviceOffering;
	}

	public void setServiceOffering(String serviceOffering) {
		this.serviceOffering = serviceOffering;
	}

	public String getOriginArea() {
		return originArea;
	}

	public void setOriginArea(String originArea) {
		this.originArea = originArea;
	}

	public String getDestinationArea() {
		return destinationArea;
	}

	public void setDestinationArea(String destinationArea) {
		this.destinationArea = destinationArea;
	}

	public Date getScheduleFrom() {
		return scheduleFrom;
	}

	public void setScheduleFrom(Date scheduleFrom) {
		this.scheduleFrom = scheduleFrom;
	}

	public Date getScheduleTo() {
		return scheduleTo;
	}

	public void setScheduleTo(Date scheduleTo) {
		this.scheduleTo = scheduleTo;
	}

	

}
