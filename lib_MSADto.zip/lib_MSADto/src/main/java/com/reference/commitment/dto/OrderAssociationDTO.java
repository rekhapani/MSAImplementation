package com.reference.commitment.dto;

import java.util.Date;



public class OrderAssociationDTO {
	private Integer orderAssocaitonId;

	public Integer getOrderAssocaitonId() {
		return orderAssocaitonId;
	}

	public void setOrderAssocaitonId(Integer orderAssocaitonId) {
		this.orderAssocaitonId = orderAssocaitonId;
	}

	public Integer getCommitmentId() {
		return commitmentId;
	}

	public void setCommitmentId(Integer commitmentId) {
		this.commitmentId = commitmentId;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Date getPickupDate() {
		return pickupDate;
	}

	public void setPickupDate(Date pickupDate) {
		this.pickupDate = pickupDate;
	}

	private Integer commitmentId;

	private Integer orderId;

	private Date pickupDate;

}
